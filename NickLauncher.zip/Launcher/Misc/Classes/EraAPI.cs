﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace EraLauncher.Misc.Classes
{
    public class EraAPI
    {
        public string GetItemContentFromCloudstorageList(string _string)
        {
           string[] list = _string.Split(new string[] { ";" }, StringSplitOptions.None);
                return list[1];
        }

    }
}
